## 什么是SaaS平台，他有什么的特点？

**SaaS 是软件即服务，英文全称：Software as a Server。**把软件租出去，用户不需要安装。

●复杂：软件庞大、安装复杂、使用复杂、运维复杂，单独购买架构昂贵，例如：ERP、CRM、BI等。

●模块化：按功能模块划分，需要什么功能就组什么模块。

●多租户：多个企业用户同时操作，使用同一个软件而不是互相干扰。当然，数据是逻辑隔离的，不同用户的数据检索字段之一必然是用户身份信息。

●通过互联网域名，区分不同的租户



## 餐掌柜业务有哪些，业务流程是什么样的？ 

●运营平台：运营商管理基础数据模块【统一权限、日志、图片、数字字典】以及商家管理的平台
●商家平台：点餐后台核心业务，提供员工、店铺、桌台、菜品、订单、结算等功能
●点餐平台：H5点餐平台，客户实现开桌、点餐、追加菜品等功能

![image.png](assets/1657534611382-acdef575-d476-460a-83ad-e90d31f06210.png)



## 你能说餐掌柜的技术架构、数据库结构吗？

![image.png](assets/1657535539201-50cb77eb-f862-48e0-b963-3c0dc97acc31.png)





![image.png](assets/1657592822617-9b9fcb8a-6912-4949-a9f0-0c9259a48a46.png)

## 什么是【通用服务】，有什么作用？

通用非业务系统的中台系统：权限、支付、图片、数字字典、日志中心、报表等



●敏捷   业务需求变化快，变更以天甚至更短的频率计算，一个单体大型应用，庞大的开发团队对单一应用的变更变得越来越困难。将大应用变为多个小的应用组合，才能适应外部的快速变化，实现业务的敏捷。
●解耦    随着业务的发展，业务系统之间的交互通常会变得越来越复杂。一个功能的修改可能会影响很多方面。只有将需要大量交互的功能独立，从应用中拆解出来，这样可以使得应用之间耦合度大幅下降。
●复用  一些公共的能力通过复用，大大提高了开发效率，避免了重复建设。同时使得数据和流程可以集中得以管理和优化。

以基础架构或基础代码做封装并对外提供公共服务



## spring-cloud-alibaba的生态圈有哪些，各个组件的作用是什么？ 



●Sentinel
阿里巴巴开源产品,把流量作为切入点,从流量控制,熔断降级,系统负载保护等多个维度保护服务的稳定性.
●Nacos
阿里巴巴开源产品,一个更易于构建云原生应用的动态服务发现,配置管理和服务管理平台.
●RocketMQ
Apache RocketMQ基于Java的高性能,高吞吐量的分布式消息和流计算平台.
●Dubbo
Apache Dubbo是一款高性能的Java RPC框架.
●Seata
阿里巴巴开源产品,一个易于使用的高性能微服务分布式事务解决方案.
●Alibaba Cloud OSS
阿里云对象存储服务器(Object Storage Service,简称OSS),是阿里云提供的海量,安全,低成本,高可靠的云存储服务.
●Alibaba Cloud Schedulerx
阿里中间件团队开发的一款分布式调度产品,支持周期性的任务与固定时间点触发任务.



## 餐掌柜需要安装哪些组件，各个组件的作用是什么？ 



展现层：负载与用户的交互，分为Android、IOS、web应用，他们都是通过访问统一的gateway网关来实现业务数据的访问
代理层：选用高性能的nginx服务，通过域名与不同servrce的绑定，通过gateway路由到不同的服务器组
权限控制层：使用无状态的JWT认证，结合Spring Security实现统一的权限控制
服务治理：使用nacos注册中心，配置中心实现服务的治理
服务调用：使用Spring Cloud alibaba 的核心组件dubbo进行服务之间的调用
流量控制：使用 Sentinel把流量作为切入点，从流量控制、熔断降级、系统负载保护等多个维度保护服务的稳定性
缓冲层：spring cache 配合redis轻松无侵入的实现业务数据的缓冲
基础业务支撑：基于spring boot脚手架，轻松集成OSS图片存储、sharding-jdbc分库分表、mybatis-plus、docker、接口文档swagger2、分布式事务seata、MySQL、RocketMQ/RabbitMQ等组件



## 运营平台采用怎样的maven分层构建，每个模块有什么作用？ 

![image.png](assets/1657598045834-a2e156b1-0963-468b-b934-285b05cbe201.png)



## 项目业务调用的链路是什么样的？

![image.png](assets/1657607893115-326947a5-27d1-4237-a039-91da02dd746e.png)

1. 用户发起请求访问Nginx，在Nginx中有反向代理的网关设置

2. 请求调用 itheima-gateway-operator网关，然后由 itheima-gateway-operator网关路由对应业务系统web项目  

3. web 项目Controller 基于 Spring依赖注入 XXFace 接口

4. XXFace 接口的实现类XXFaceImpl 基于 Spring依赖注入 XXService 接口

5. XXService 接口的实现类调用 XXMapper完成对数据库的 CRUD操作

6. itheima-module-job 否则基于 MQ 完成业务日志采集和存储工作

   

##  BasicPojo的作用? 如何完成对通用字段的填充?(是否使用过mybatisplus自定填充)

各个模块中POJO对象继承的基础父类
	隶属模块：framework-mybatis-plus
	包路径：com.itheima.project.basic
	作用：所有实体类公共字段的定义

```java

package com.itheima.project.basic;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.itheima.restkeeper.utils.ToString;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import java.io.Serializable;
import java.util.Date;
/**
 * @Description：实体基础类
 */
@Data
@NoArgsConstructor
public class BasicPojo implements Serializable {
    //主键
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    public Long id;
    //分片键
    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    public Long shardingId;
    //创建时间
    @TableField(fill = FieldFill.INSERT)//INSERT代表只在插入时填充
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")//set
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")//get
    public Date createdTime;
    //修改时间
    @TableField(fill = FieldFill.INSERT_UPDATE)// INSERT_UPDATE 首次插入、其次更新时填充(或修改)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")//set
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")//get
    public Date updatedTime;
    //是否有效
    @TableField(fill = FieldFill.INSERT)
    public String enableFlag;
    //构造函数
    public BasicPojo(Long id) {
        this.id = id;
    }
}
```

