##  redisson如何配置Single和Cluster模式？

redission 单机版配置文件

```yaml
singleServerConfig:
   #如果当前连接池里的连接数量超过了最小空闲连接数，而同时有连接空闲时间超过了该数值，
   #那么这些连接将会自动被关闭，并从连接池里去掉。时间单位是毫秒。
   #默认值：10000
   idleConnectionTimeout: 10000
   pingTimeout: 1000
   #同任何节点建立连接时的等待超时。时间单位是毫秒。
   #默认值：10000
   connectTimeout: 10000
   #等待节点回复命令的时间。该时间从命令发送成功时开始计时。
   #默认值：3000
   timeout: 3000
   #如果尝试达到 retryAttempts（命令失败重试次数）
   #仍然不能将命令发送至某个指定的节点时，将抛出错误。如果尝试在此限制之内发送成功，
   #则开始启用 timeout（命令等待超时） 计时。
   #默认值：3
   retryAttempts: 3
   #在某个节点执行相同或不同命令时，连续失败failedAttempts（执行失败最大次数）时，
   #该节点将被从可用节点列表里清除，直到 reconnectionTimeout（重新连接时间间隔） 超时以后再次尝试。
   #默认值：1500
   retryInterval: 1500
   #重新连接时间间隔
   reconnectionTimeout: 3000
   #执行失败最大次数
   failedAttempts: 3
   #密码
   password: null
   #每个连接的最大订阅数量。
   #默认值：5
   subscriptionsPerConnection: 5
   #在Redis节点里显示的客户端名称。
   clientName: null
   #在Redis节点
   address: "redis://192.168.200.128:6379"
   #从节点发布和订阅连接的最小空闲连接数
   #默认值：1
   subscriptionConnectionMinimumIdleSize: 1
   #用于发布和订阅连接的连接池最大容量。连接池的连接数量自动弹性伸缩。
   #默认值：50
   subscriptionConnectionPoolSize: 50
   #节点最小空闲连接数
   #默认值：32
   connectionMinimumIdleSize: 32
   #节点连接池大小
   #默认值：64
   connectionPoolSize: 64
 #这个线程池数量被所有RTopic对象监听器，RRemoteService调用者和RExecutorService任务共同共享。
 #默认值: 当前处理核数量 * 2
 threads: 8
 #这个线程池数量是在一个Redisson实例内，被其创建的所有分布式数据类型和服务，
 #以及底层客户端所一同共享的线程池里保存的线程数量。
 #默认值: 当前处理核数量 * 2
 nettyThreads: 8
 #Redisson的对象编码类是用于将对象进行序列化和反序列化，以实现对该对象在Redis里的读取和存储。
 #默认值: org.redisson.codec.JsonJacksonCodec
 codec: !<org.redisson.codec.JsonJacksonCodec> {}
 #传输模式
 #默认值：TransportMode.NIO
 transportMode: "NIO"
```



redission 集群版配置文件

```yaml

 clusterServersConfig:
   #如果当前连接池里的连接数量超过了最小空闲连接数，而同时有连接空闲时间超过了该数值，
   #那么这些连接将会自动被关闭，并从连接池里去掉。时间单位是毫秒。
   #默认值：10000
   idleConnectionTimeout: 10000
   #同任何节点建立连接时的等待超时。时间单位是毫秒。
   #默认值：10000
   connectTimeout: 10000
   #等待节点回复命令的时间。该时间从命令发送成功时开始计时。
   #默认值：3000
   timeout: 3000
   #如果尝试达到 retryAttempts（命令失败重试次数）
   #仍然不能将命令发送至某个指定的节点时，将抛出错误。如果尝试在此限制之内发送成功，
   #则开始启用 timeout（命令等待超时） 计时。
   #默认值：3
   retryAttempts: 3
   #在某个节点执行相同或不同命令时，连续失败failedAttempts（执行失败最大次数）时，
   #该节点将被从可用节点列表里清除，直到 reconnectionTimeout（重新连接时间间隔） 超时以后再次尝试。
   #默认值：1500
   retryInterval: 1500
   #密码
   password: null
   #每个连接的最大订阅数量。
   #默认值：5
   subscriptionsPerConnection: 5
   clientName: null
   #负载均衡算法类的选择
   #默认值： org.redisson.connection.balancer.RoundRobinLoadBalancer
   #在使用多个Elasticache Redis服务节点的环境里，可以选用以下几种负载均衡方式选择一个节点：
     #org.redisson.connection.balancer.WeightedRoundRobinBalancer - 权重轮询调度算法
     #org.redisson.connection.balancer.RoundRobinLoadBalancer - 轮询调度算法
     #org.redisson.connection.balancer.RandomLoadBalancer - 随机调度算法
   loadBalancer: !<org.redisson.connection.balancer.RoundRobinLoadBalancer> {}
   slaveSubscriptionConnectionMinimumIdleSize: 1
   slaveSubscriptionConnectionPoolSize: 50
   slaveConnectionMinimumIdleSize: 32
   slaveConnectionPoolSize: 64
   masterConnectionMinimumIdleSize: 32
   masterConnectionPoolSize: 64
   readMode: "SLAVE"
   nodeAddresses:
     - "redis://192.168.200:128:7001"
     - "redis://192.168.200.128:7002"
     - "redis://192.168.200.128:7003"
   scanInterval: 1000
 threads: 0
 nettyThreads: 0
 codec: !<org.redisson.codec.JsonJacksonCodec> {}
 "transportMode":"NIO"
```



## redisson分布式锁原理及常用使用API有那些？ 

![image-20210517110113769.png](assets/1670003724821-bf849c44-8a5b-4cae-8a86-d9826587e056.png)

**●**加锁机制 
   线程A：线程去获取锁，获取成功: 执行lua脚本，保存数据到redis数据库。
   线程B：线程去获取锁，获取失败: 一直通过while循环尝试获取锁，获取成功后，执行lua脚本，保存数据到redis

## 看门狗机制是什么？解决什么问题？

**第一种情况**：在一个分布式环境下，假如一个线程获得锁后，突然服务器宕机了，那么这个时候在一定时间后这个锁会自动释放，你也可以设置锁的有效时间(不设置默认30秒），这样的目的主要是防止死锁的发生
**第二种情况**：线程A业务还没有执行完，时间就过了，线程A 还想持有锁的话，就会启动一个watch dog后台线程，不断的延长锁key的生存时间



## 桌台是否开台的前提条件是什么？

桌台是否开台的前提条件：
●当前桌台处于空闲状态且无订单，认为桌台未开台，可以使用
●当前桌台存在处于【待付款、支付中】的订单，认为当前桌台已开台



## 查询相关主体时需要统一查询哪些数据？ 核心的字段是什么？

查询品牌、门店、区域、桌台、菜品分类、菜品等相关的信息

核心字段是tableId



## 简述开桌流程，开桌中我们为什么要加分布式锁？其注意事项有那些？ 

防止并发重复创建订单 

1、锁定桌台，防止并发重复创建订单 — 分布式锁

2、幂等性：再次查询桌台订单情况 

3、未开台,为桌台创建订单，并设置订单状态为： DFK 

​    3.1、查询桌台信息

​    3.2、构建订单 

4、修改桌台状态为使用中 

5、查询订单处理：处理可核算订单项和购物车订单项，可调用桌台订单显示接口
6、释放分布式锁

## 什么是幂等性，实现幂等性的方案有哪些？ 

（参考：https://blog.csdn.net/Javaesandyou/article/details/124097590）

幂等性：是指无论调用多少次都不会有不同结果的 HTTP 方法。不管你调用一次，还是调用一百次，一千次，结果都是相同的。

1、前端拦截（前端拦截是指通过 Web 站点的页面进行请求拦截，比如在用户点击完“提交”按钮后，我们可以把按钮设置为不可用或者隐藏状态，避免用户重复点击。）

2、使用数据库实现幂等性（乐观锁 > 唯一约束 > 悲观锁）

​       a、通过悲观锁来实现幂等性

​       b、通过唯一索引来实现幂等性

​       c、通过乐观锁来实现幂等性

3、使用 JVM 锁实现幂等性（指通过 JVM 提供的内置锁如 Lock 或者是 synchronized 来实现幂等性。）

4、使用[分布式锁](https://so.csdn.net/so/search?q=分布式锁&spm=1001.2101.3001.7020)实现幂等性（分布式锁实现幂等性的逻辑是，在每次执行方法之前先判断是否可以获取到分布式锁，如果可以，则表示为第一次执行方法，否则直接舍弃请求即可）



## 订单创建时机是什么？ 

用户将菜加入购物车时



## 什么是可核算订单项？ 什么是购物车项？  分别存到哪里？

1、可核算订单项【已下单可结算】：MySQL
2、购物车订单项【已加入购物车未下单】：Redis



## 菜品价格字段使用的类型是什么？如何对BigDecimal进行加减乘除运算？如何比较两个BigDecimal的大小?

（参考：https://blog.csdn.net/weixin_43888891/article/details/115315370）

double类型，使用对应api

加：public  BigDecimal add(BigDecimal augend);

减：public [BigDecimal](https://blog.csdn.net/AttleeTao/java/math/BigDecimal.html) subtract([BigDecimal](https://blog.csdn.net/AttleeTao/java/math/BigDecimal.html) subtrahend);

乘：public BigDecimal multiply(BigDecimal multiplicand);

除：public BigDecimal divide(BigDecimal divisor);

等于：new BigDecimal(“123.123”).compareTo(new BigDecimal(“123.123”))==0   —> true
小于：new BigDecimal(“123.122”).compareTo(new BigDecimal(“123.123”)) < 0   —> true就证明左边小于右边
大于：new BigDecimal(“123.124”).compareTo(new  BigDecimal(“123.123”)) > 0   —> true就证明左边大于右边

