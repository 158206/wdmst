## ● 订单Order，交易单Trade, 和三方支付是如何关联的?

transaction_id  订单编号



## ● 订单Order有哪些状态?

待支付、支付中、免单、支付失败、已结算、退款



## ●请求支付生成二维码、查询支付状态、退款接口有哪些核心参数?    

orderNo  appid  mchid  商户秘钥  openid(小程序) app秘钥(小程序)

