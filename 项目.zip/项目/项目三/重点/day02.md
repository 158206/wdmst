## 项目中对图片数据引用设计

**通过fegin调用文件组件,实现文件的CRUD**

文件表中business_id与具体业务id形成逻辑外键
文件表中business_type表示具体业务类型与数据字典形成逻辑外键

```sql
CREATE TABLE `tab_file` (
  `id` bigint(18) NOT NULL COMMENT '主键',
  `business_id` bigint(18) DEFAULT NULL COMMENT '业务ID',
  `business_type` varchar(36) DEFAULT NULL COMMENT '业务类型',
  `suffix` varchar(10) DEFAULT NULL COMMENT '后缀名',
  `file_name` varchar(200) DEFAULT NULL COMMENT '文件名',
  `path_url` varchar(200) DEFAULT NULL COMMENT '访问路径',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_time` datetime DEFAULT NULL COMMENT '创建时间',
  `sharding_id` bigint(18) DEFAULT NULL COMMENT '分库ID',
  `enable_flag` varchar(10) CHARACTER SET utf8 DEFAULT NULL COMMENT '是否有效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='附件';
```



## 项目中数据字典表的引用设计



```sql
CREATE TABLE `tab_data_dict` (
  `id` bigint(18) NOT NULL,
  `parent_key` varchar(255) NOT NULL COMMENT '父key',
  `data_key` varchar(255) NOT NULL COMMENT '数据字典KEY',
  `data_value` varchar(255) NOT NULL COMMENT '值',
  `discriptioin` varchar(255) DEFAULT NULL COMMENT '描述',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_time` datetime DEFAULT NULL COMMENT '创建时间',
  `sharding_id` bigint(18) DEFAULT NULL COMMENT '分库ID',
  `enable_flag` varchar(10) NOT NULL COMMENT '是否有效',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='数据字典表';
```

其中 parent_key 字段为 BRAND_CATEGORY 代表具体业务对应的分类

![image.png](assets/1657677664798-0149857a-3ae9-481c-bfa3-8adf8b6d7677.png)

## 项目中服务之间调用设计

```
Controller->Face->Service->Dao
Controller->Face->Feign
```

![image.png](assets/1657695387112-0793b131-6d91-47f1-97df-1ac7b8da2448.png)

1. BrandController：品牌对外提供 Http 请求接口，并提供 Swagger接口文档
2. BrandFace：品牌业务处理接口定义
3. BrandFaceImpl：品牌业务处理接口定义实现，这里做VO和POJO之间转换
4. FileFeign【文件服务】：文件服务对位提供的Feign 接口
5. IBrandService：品牌的数据接口定义，为BrandFaceImpl提供核心业务逻辑的定义
6. BrandServiceImpl：品牌的数据接口定义实现